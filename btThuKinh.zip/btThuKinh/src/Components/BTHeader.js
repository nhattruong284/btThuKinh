import React, { Component } from 'react'

export default class BTHeader extends Component {
    render() {
        return (
            
                <nav className="bg-secondary text-white text-center py-3">
                    TRY GLASSES APP ONLINE
                </nav>

            
        )
    }
}
