import logo from './logo.svg';
import './App.css';
import BTThuKinh from './Components/BTThuKinh';

function App() {
  return (
    <div className="App">
      <BTThuKinh />
    </div>
  );
}

export default App;
